<?php

$conn = mysqli_connect('localhost', 'root', '', 'sis');
if ($conn == false) echo "Connection Lost!";
