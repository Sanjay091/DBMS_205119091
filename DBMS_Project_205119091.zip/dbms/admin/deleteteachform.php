<?php

include('../dbconn.php');

$ei = $_REQUEST['eid'];
$qry = "DELETE FROM `teacher` WHERE `eid`='$ei'";

$run = mysqli_query($conn, $qry);

if ($run == true) {
    ?>
    <script type="text/javascript">
        alert('Data Deleted!');
        window.open('admindash.php', '_self');
    </script>
<?php
}

?>